export default (req,res) => {
    res.writeHead(200,{'Content-type': 'text/plain'});
    res.end('This is me ');}